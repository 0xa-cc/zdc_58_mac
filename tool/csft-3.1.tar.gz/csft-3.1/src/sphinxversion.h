#define SPH_SVN_TAG ""
#define SPH_SVN_REV 1566
#define SPH_SVN_REVSTR "1566"
#define SPH_SVN_TAGREV "r1566"
